<?php

/* @var $this \yii\web\View */
/* @var $directoryAsset false|string */

?>

<div class="page-footer">
	Copyright &copy; 2014-<?=date("Y")?>&nbsp;
	<a href="https://github.com/AndrewDanilov/" target="_blank">Andrew Danilov</a>.
	All rights reserved.
</div>