<?php

/* @var $this \yii\web\View */
/* @var $label string */
/* @var $microdata bool */
/* @var $position int */

?>

<li class="item">
	<span><?= $label ?></span>
</li>