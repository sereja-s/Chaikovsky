<?php

/* @var $this \yii\web\View */
/* @var $content string */

?>

<ul class="menu">

	<?= $content ?>

</ul>